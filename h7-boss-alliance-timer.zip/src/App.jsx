
import { useEffect, useState } from "react";

export default function App() {
  return (
    <div style={{ background: "black", color: "white", minHeight: "100vh", padding: 20 }}>
      <h1>H7 BOSS ALLIANCE TIMER</h1>
      <p>Boss timer app successfully deployed.</p>
    </div>
  );
}
